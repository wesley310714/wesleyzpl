# Wesley ZPL Converter

Conversor simples de PDF para ZPL (10x15cm) para impressoras Zebra.

Feito para uso interno por Wesley.
